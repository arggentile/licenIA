"""Pruebas mínimas (sin framework externo).

Ejecutar: `python -m incidentes.tests`. Si hay algún fallo, se levanta
AssertionError y se ve la traza. Si todo pasa, imprime OK.
"""

from __future__ import annotations

import random
from datetime import datetime

from .algorithms import (
    busqueda_binaria,
    busqueda_secuencial,
    insertion_sort,
    mergesort,
)
from .event import Event
from .event_store import EventStore
from .router import Router
from .structures import PriorityQueue, Queue
from .text_analyzer import TextAnalyzer


def _ev(id_: str, p: int, cat: str = "red", texto: str = "x",
        origen: str = "A", destino: str = "B") -> Event:
    return Event(
        prioridad=p,
        timestamp=datetime(2025, 1, 1, 0, int(id_[1:]) % 60),
        id=id_,
        categoria=cat,
        texto=texto,
        origen=origen,
        destino=destino,
    )


def test_event_store() -> None:
    s = EventStore()
    s.add(_ev("E01", 3))
    s.add(_ev("E02", 1))
    assert len(s) == 2
    assert s.get("E01").id == "E01"
    assert s.get("no-existe") is None
    try:
        s.add(_ev("E01", 5))
        raise AssertionError("debía fallar por id duplicado")
    except ValueError:
        pass


def test_index() -> None:
    s = EventStore()
    s.add_many([_ev("E01", 1, cat="red"), _ev("E02", 2, cat="red"),
                _ev("E03", 3, cat="seguridad")])
    idx = s.crear_indice("cat", "categoria")
    assert len(idx.get("red")) == 2
    assert len(idx.get("seguridad")) == 1
    assert idx.get("inexistente") == []


def test_queue() -> None:
    q: Queue[int] = Queue()
    for i in range(5):
        q.enqueue(i)
    assert q.peek() == 0
    assert [q.dequeue() for _ in range(5)] == [0, 1, 2, 3, 4]


def test_priority_queue() -> None:
    pq = PriorityQueue()
    pq.push(_ev("E01", 5))
    pq.push(_ev("E02", 1))
    pq.push(_ev("E03", 3))
    assert pq.pop().id == "E02"   # prioridad 1 = más urgente
    assert pq.pop().id == "E03"
    assert pq.pop().id == "E01"


def test_busquedas() -> None:
    datos = list(range(100))
    assert busqueda_secuencial(datos, 42) == 42
    assert busqueda_secuencial(datos, 999) == -1
    assert busqueda_binaria(datos, 42) == 42
    assert busqueda_binaria(datos, 999) == -1


def test_ordenamientos() -> None:
    rng = random.Random(1)
    datos = [rng.randint(0, 1000) for _ in range(200)]
    esperado = sorted(datos)
    assert insertion_sort(datos.copy()) == esperado
    assert mergesort(datos) == esperado


def test_text_analyzer() -> None:
    evs = [_ev("E01", 1, texto="caida de enlace"),
           _ev("E02", 2, texto="acceso no autorizado")]
    ta = TextAnalyzer(evs)
    assert len(ta.buscar("enlace")) == 1
    assert len(ta.buscar("ACCESO")) == 1   # case insensitive
    assert ta.contar_por_palabra(["enlace", "acceso"]) == {"enlace": 1, "acceso": 1}


def test_router() -> None:
    r = Router()
    r.registrar(_ev("E01", 1, origen="A", destino="B"))
    r.registrar(_ev("E02", 2, origen="A", destino="C"))
    assert r.vecinos("A") == ["B", "C"]
    assert r.existe_arista("A", "B")
    assert not r.existe_arista("B", "A")


def main() -> None:
    tests = [v for k, v in globals().items() if k.startswith("test_")]
    for t in tests:
        t()
        print(f"  ok  {t.__name__}")
    print(f"\nTodo OK ({len(tests)} pruebas).")


if __name__ == "__main__":
    main()
