"""Router: red de rutas entre orígenes y destinos.

En esta Parte 1 el `Router` cumple un rol mínimo: registra las aristas
(origen, destino) derivadas de los eventos y responde consultas simples
(vecinos de un nodo, existencia de arista). El análisis completo con
grafos (BFS/DFS, caminos mínimos, componentes conexos) se abordará en la
Parte 2 de la evaluación.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Iterable

from .event import Event


class Router:
    """Grafo dirigido implementado con listas de adyacencia."""

    def __init__(self) -> None:
        self._ady: dict[str, set[str]] = defaultdict(set)

    def registrar(self, evento: Event) -> None:
        """Agrega la arista origen -> destino del evento."""
        self._ady[evento.origen].add(evento.destino)
        # Asegurar que el destino aparezca como nodo aunque no tenga salidas.
        _ = self._ady[evento.destino]

    def registrar_muchos(self, eventos: Iterable[Event]) -> None:
        for e in eventos:
            self.registrar(e)

    def vecinos(self, nodo: str) -> list[str]:
        return sorted(self._ady.get(nodo, set()))

    def nodos(self) -> list[str]:
        return sorted(self._ady.keys())

    def existe_arista(self, origen: str, destino: str) -> bool:
        return destino in self._ady.get(origen, set())
