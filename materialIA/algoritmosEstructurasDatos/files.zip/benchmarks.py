"""Mediciones con `timeit` para búsquedas y ordenamientos.

Se ejecuta como script: `python -m incidentes.benchmarks`. Imprime una
tabla con tiempos (en milisegundos) para tamaños crecientes de entrada.

Nota metodológica: usamos `timeit.repeat` con varias repeticiones y nos
quedamos con el mejor tiempo, que es lo recomendado por la documentación
oficial para minimizar ruido (procesos del sistema, GC, etc.).
"""

from __future__ import annotations

import random
import timeit
from typing import Callable

from .algorithms import (
    busqueda_binaria,
    busqueda_secuencial,
    insertion_sort,
    mergesort,
)


TAMANOS = [1_000, 5_000, 10_000, 50_000]
REPS = 3
NUMBER = 1  # una ejecución por repetición; cada corrida ya es costosa


def _tiempo(fn: Callable[[], None]) -> float:
    """Devuelve el mejor tiempo en milisegundos."""
    tiempos = timeit.repeat(fn, repeat=REPS, number=NUMBER)
    return min(tiempos) * 1000.0


def bench_busquedas() -> None:
    print("\n=== Búsqueda: secuencial vs binaria (encontrar último elemento) ===")
    print(f"{'n':>8} | {'secuencial (ms)':>18} | {'binaria (ms)':>14}")
    print("-" * 50)
    for n in TAMANOS:
        datos = list(range(n))
        objetivo = n - 1  # peor caso para secuencial
        t_sec = _tiempo(lambda: busqueda_secuencial(datos, objetivo))
        t_bin = _tiempo(lambda: busqueda_binaria(datos, objetivo))
        print(f"{n:>8} | {t_sec:>18.4f} | {t_bin:>14.4f}")


def bench_ordenamientos() -> None:
    print("\n=== Ordenamiento: insertion vs mergesort vs sorted() ===")
    print(
        f"{'n':>8} | {'insertion (ms)':>16} | "
        f"{'mergesort (ms)':>16} | {'sorted (ms)':>12}"
    )
    print("-" * 62)
    random.seed(42)
    for n in TAMANOS:
        base = [random.randint(0, n * 10) for _ in range(n)]

        # insertion sort se vuelve inviable en tamaños grandes: lo salteamos > 10k
        if n <= 10_000:
            t_ins = _tiempo(lambda: insertion_sort(base.copy()))
            ins_str = f"{t_ins:>16.4f}"
        else:
            ins_str = f"{'(salteado)':>16}"

        t_merge = _tiempo(lambda: mergesort(base))
        t_sorted = _tiempo(lambda: sorted(base))
        print(f"{n:>8} | {ins_str} | {t_merge:>16.4f} | {t_sorted:>12.4f}")


if __name__ == "__main__":
    bench_busquedas()
    bench_ordenamientos()
