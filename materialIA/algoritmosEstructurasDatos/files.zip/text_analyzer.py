"""Analizador de texto para descripciones de eventos.

Alcance de esta Parte 1: búsqueda de subcadenas por fuerza bruta y por
`in` (que en CPython usa un algoritmo tipo Two-Way / Crochemore-Perrin
optimizado). Los patrones más avanzados (autómatas, KMP, expresiones
regulares para reglas de alertas) quedan para la Parte 2, junto con
árboles/tries si aplica.
"""

from __future__ import annotations

from typing import Iterable

from .event import Event


class TextAnalyzer:
    """Búsqueda de palabras clave dentro de las descripciones."""

    def __init__(self, eventos: Iterable[Event]) -> None:
        self._eventos = list(eventos)

    def buscar(self, patron: str, *, case_sensitive: bool = False) -> list[Event]:
        """Devuelve los eventos cuyo texto contiene el patrón.

        Complejidad: O(n * m) en el peor caso, con n = cantidad de eventos
        y m = costo de la búsqueda de subcadena (que Python realiza en
        tiempo aproximadamente lineal sobre el largo del texto).
        """
        if not case_sensitive:
            patron = patron.lower()
            return [
                e for e in self._eventos if patron in e.texto.lower()
            ]
        return [e for e in self._eventos if patron in e.texto]

    def contar_por_palabra(self, palabras: Iterable[str]) -> dict[str, int]:
        """Cuenta cuántos eventos mencionan cada palabra (case-insensitive)."""
        conteos = {p.lower(): 0 for p in palabras}
        for e in self._eventos:
            t = e.texto.lower()
            for p in conteos:
                if p in t:
                    conteos[p] += 1
        return conteos
