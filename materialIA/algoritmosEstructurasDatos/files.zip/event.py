"""Modelo de dominio: la clase Event.

Cada incidente que procesa la plataforma se representa como una instancia
de `Event`. Se usa `dataclass` para reducir código repetitivo (constructor,
igualdad y `repr` gratis) y `field(compare=False)` en `texto` para que la
comparación entre eventos no dependa del contenido libre de la descripción.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass(order=True)
class Event:
    """Representa un incidente.

    Los atributos siguen el enunciado: id, timestamp, categoría, prioridad,
    texto, origen y destino. `prioridad` es un entero donde valores más
    bajos indican mayor urgencia (convención estándar de heaps en Python).

    Atributos:
        id: Identificador único del incidente.
        timestamp: Momento en que ocurrió (datetime).
        categoria: Etiqueta temática (p. ej. "red", "seguridad").
        prioridad: Entero; 1 = crítica, 5 = baja (menor es más urgente).
        texto: Descripción libre del incidente.
        origen: Nodo/ubicación de origen (para el módulo de rutas).
        destino: Nodo/ubicación de destino.
    """

    # El orden de los campos importa para @dataclass(order=True): al comparar
    # dos Event se comparará primero por prioridad y luego por timestamp,
    # que es lo que necesita la cola de prioridad.
    prioridad: int
    timestamp: datetime
    id: str = field(compare=False)
    categoria: str = field(compare=False)
    texto: str = field(compare=False, repr=False)
    origen: str = field(compare=False)
    destino: str = field(compare=False)

    def resumen(self) -> str:
        """Devuelve una línea corta útil para logs y demos."""
        return (
            f"[{self.prioridad}] {self.id} {self.categoria} "
            f"{self.origen}->{self.destino} @ {self.timestamp.isoformat()}"
        )
