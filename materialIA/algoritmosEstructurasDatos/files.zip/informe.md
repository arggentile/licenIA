# Informe — Parte 1: Plataforma de análisis de incidentes y rutas

## 1. Diseño del sistema (POO + modularidad)

El sistema se organiza como un paquete Python `incidentes/` con un módulo por responsabilidad. Cada clase encapsula un aspecto del problema y expone una interfaz mínima, siguiendo el principio de responsabilidad única.

| Módulo | Clase | Responsabilidad |
|---|---|---|
| `event.py` | `Event` | Representar un incidente (id, timestamp, categoría, prioridad, texto, origen, destino). |
| `event_store.py` | `EventStore` | Almacenar eventos y ofrecer acceso O(1) por id. |
| `index.py` | `Index` | Índice hash multi-valor sobre un atributo de `Event`. |
| `router.py` | `Router` | Grafo dirigido de rutas origen→destino (base para Parte 2). |
| `text_analyzer.py` | `TextAnalyzer` | Búsqueda de patrones de texto en las descripciones. |
| `structures.py` | `Queue`, `PriorityQueue` | TDA lineales (FIFO y por prioridad). |
| `algorithms.py` | — | Búsquedas y ordenamientos didácticos. |
| `benchmarks.py` | — | Mediciones con `timeit`. |
| `demo.py`, `tests.py` | — | Demostración y pruebas. |

**Decisiones de diseño principales:**

- **`Event` como `@dataclass(order=True)`** con `prioridad` como primer campo. Esto vuelve a los eventos naturalmente comparables por urgencia y elimina código repetitivo (constructor, `__repr__`, igualdad).
- **`EventStore` mantiene una lista y un dict**: la lista preserva el orden de llegada (útil para recorridos y para benchmark de búsqueda secuencial); el dict provee lookup O(1) promedio por id.
- **Índices secundarios bajo demanda**: no se pre-computan todos los índices; el usuario decide cuáles crear con `crear_indice("por_categoria", "categoria")`. Esto ahorra memoria si un índice no se necesita.
- **`Router` y `TextAnalyzer` en versión mínima**: el enunciado los pide en el diseño, pero su desarrollo pleno (BFS/DFS, KMP, regex de alertas) corresponde a la Parte 2. Se dejan las interfaces listas para extender sin romper compatibilidad.

## 2. Estructuras lineales

Se implementaron dos TDA sobre primitivas de la biblioteca estándar:

**`Queue` (FIFO) sobre `collections.deque`** — cola de doble extremo que garantiza operaciones O(1) en ambos extremos, a diferencia de una `list` de Python donde `pop(0)` es O(n).

| Operación | Complejidad |
|---|---|
| `enqueue` | O(1) |
| `dequeue` | O(1) |
| `peek` | O(1) |

**`PriorityQueue` sobre `heapq`** — min-heap binario. Se guardan tuplas `(prioridad, timestamp, contador, evento)`; el contador funciona como desempate para preservar el orden de inserción cuando hay empate (`heapq` no es estable de fábrica).

| Operación | Complejidad |
|---|---|
| `push` | O(log n) |
| `pop` | O(log n) |
| `peek` | O(1) |

En el caso de uso: la `Queue` sirve como bandeja de entrada FIFO, mientras la `PriorityQueue` decide **a quién atender primero** en función de la severidad (menor valor = más urgente) y del timestamp como desempate. Esta separación deja claro el rol de cada estructura y evita mezclar "orden de llegada" con "orden de atención".

## 3. Búsqueda, ordenamiento y medición

**Búsqueda.** Se implementaron búsqueda secuencial (O(n)) y binaria (O(log n)) usando `bisect_left`. La binaria requiere secuencia ordenada, por lo que se paga una vez el costo del ordenamiento y luego se amortiza en muchas consultas.

**Ordenamiento.** Se eligieron **inserción** y **mergesort** por ser los más didácticos: representan las dos grandes familias (cuadrático simple vs. divide-y-vencerás lineal-logarítmico) y ambos son estables. Ambos aceptan un `key` para ordenar por cualquier atributo del evento (p. ej. por `timestamp` o por `prioridad`), replicando la interfaz de `sorted()`.

**Mediciones.** Ejecutadas con `timeit.repeat`, quedándonos con el mejor tiempo por corrida (recomendación oficial para reducir ruido).

**Búsqueda — hallar el último elemento (peor caso para secuencial):**

| n | Secuencial (ms) | Binaria (ms) |
|---:|---:|---:|
| 1 000 | 0.0307 | 0.0007 |
| 5 000 | 0.1448 | 0.0008 |
| 10 000 | 0.2659 | 0.0005 |
| 50 000 | 1.4066 | 0.0005 |

La secuencial crece linealmente (multiplica por ~5 al multiplicar n por 5); la binaria se mantiene prácticamente constante en el tiempo mínimo medible, coherente con log₂(50000) ≈ 16 iteraciones.

**Ordenamiento — lista aleatoria de enteros:**

| n | Inserción (ms) | Mergesort (ms) | `sorted()` (ms) |
|---:|---:|---:|---:|
| 1 000 | 18.84 | 2.10 | 0.10 |
| 5 000 | 493.93 | 12.89 | 0.63 |
| 10 000 | 1 976.62 | 24.83 | 1.48 |
| 50 000 | (salteado) | 144.62 | 8.70 |

Al pasar de 5 000 a 10 000 elementos, inserción **cuadruplica** su tiempo (comportamiento O(n²)) mientras que mergesort apenas se duplica (O(n log n)). `sorted()` es aproximadamente **15–20× más rápido** que nuestro mergesort, porque implementa Timsort en C: aprovecha runs ordenados naturales y evita el overhead de las llamadas recursivas en Python. La lección práctica: implementar algoritmos clásicos es didáctico, pero en producción conviene usar `sorted()`/`list.sort()`.

## 4. Hashing e índices

El índice se implementa sobre `dict` mediante la clase `Index` (multi-valor: cada clave apunta a la lista de eventos que la comparten). `EventStore` mantiene además su propio dict `id → Event` para lookup directo.

**Sobre colisiones (conceptual).** Una tabla hash mapea claves a posiciones (buckets) mediante una función `hash`. Cuando dos claves distintas caen en el mismo bucket ocurre una **colisión**. Las estrategias clásicas son:

- **Encadenamiento**: cada bucket guarda una lista con todos los elementos que colisionan. Sencillo de implementar, pero paga indirección de memoria.
- **Direccionamiento abierto**: si el bucket está ocupado, se busca otro slot libre siguiendo una secuencia de sondeo (lineal, cuadrático o doble hashing). Buena localidad de caché, pero exige redimensionar la tabla cuando el factor de carga sube.

**Elección: `dict` de CPython.** Usa direccionamiento abierto con sondeo perturbado y redimensiona automáticamente para mantener el factor de carga por debajo de 2/3, lo que garantiza operaciones O(1) promedio. Está implementado en C y es una de las estructuras más optimizadas del lenguaje; reescribir una tabla hash en Python puro sería siempre más lento y didácticamente aporta poco frente a lo que ya se ve en `algorithms.py`.

## 5. Síntesis integradora

**¿Qué decisiones mejoraron el rendimiento y por qué?**
El cambio de mayor impacto es el **índice hash por id**: pasa de una búsqueda O(n) sobre la lista a O(1) promedio. En una base con 50 000 eventos, la diferencia medida es de ~1.4 ms a menos de 0.001 ms por consulta. El segundo cambio importante es usar `heapq` para priorizar la atención: mantener un ranking dinámico con `sorted()` en cada inserción sería O(n log n) por evento; con el heap es O(log n). Y para consultas frecuentes por valor exacto (`prioridad == p`), el índice secundario también evita recorrer todo el store.

**¿Dónde aparece el trade-off tiempo vs memoria?**
En cada índice creado. `EventStore` podría contentarse con la lista de llegada (ínfima memoria extra) y buscar cada consulta linealmente. Al mantener un `dict` por id y otros `Index` secundarios se duplican o triplican punteros a los mismos objetos —los eventos no se copian, pero cada índice suma su propia tabla— a cambio de bajar consultas típicas de O(n) a O(1). Otro caso es mergesort: gana orden en tiempo respecto a inserción (O(n log n) vs O(n²)) al precio de O(n) de memoria auxiliar para el merge, mientras que inserción trabaja in-place con O(1) extra.

**¿Cómo se conectan POO, modularidad, estructuras y medición para construir software mantenible?**
La POO da límites claros: `Event` es un dato, `EventStore` un repositorio, `PriorityQueue` una política de atención. Cada uno se puede leer, testear y reemplazar sin tocar el resto. La **modularidad** —un archivo por responsabilidad— hace que la Parte 2 pueda extender `Router` con BFS o `TextAnalyzer` con KMP sin romper el código existente. Las **estructuras** elegidas (dict, deque, heap) son las que dan las complejidades objetivo; sin ellas, ninguna elegancia de diseño rescataría el rendimiento. Y las **mediciones con `timeit`** cierran el ciclo: convierten decisiones de diseño en evidencia empírica ("mergesort escala, inserción no") y detectan regresiones cuando algo cambia. Juntos, los cuatro pilares producen software que no solo funciona hoy, sino que se puede evolucionar mañana con confianza.

---

## Cómo ejecutar

```bash
# desde el directorio que contiene la carpeta incidentes/
python -m incidentes.tests        # pruebas mínimas
python -m incidentes.demo         # demostración end-to-end
python -m incidentes.benchmarks   # mediciones con timeit
```
