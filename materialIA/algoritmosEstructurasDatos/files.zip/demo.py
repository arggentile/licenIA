"""Demostración integrada de la Parte 1.

Ejecutar: `python -m incidentes.demo`.

Crea eventos de ejemplo, los carga en el EventStore, arma índices,
prioriza atención con la cola de prioridad, hace búsquedas de texto y
consultas al grafo de rutas.
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta

from .event import Event
from .event_store import EventStore
from .router import Router
from .structures import PriorityQueue, Queue
from .text_analyzer import TextAnalyzer


CATEGORIAS = ["red", "seguridad", "energia", "software"]
NODOS = ["A", "B", "C", "D", "E"]
FRASES = [
    "caida de enlace principal",
    "acceso no autorizado detectado",
    "corte de suministro electrico",
    "servicio degradado por alto trafico",
    "alerta de temperatura en sala",
    "actualizacion fallida en nodo",
]


def _sample_eventos(n: int, semilla: int = 7) -> list[Event]:
    rng = random.Random(semilla)
    base = datetime(2025, 1, 1)
    eventos = []
    for i in range(n):
        origen, destino = rng.sample(NODOS, 2)
        eventos.append(
            Event(
                prioridad=rng.randint(1, 5),
                timestamp=base + timedelta(minutes=i),
                id=f"E{i:04d}",
                categoria=rng.choice(CATEGORIAS),
                texto=rng.choice(FRASES),
                origen=origen,
                destino=destino,
            )
        )
    return eventos


def main() -> None:
    eventos = _sample_eventos(20)

    # 1) Almacén + índice por id (O(1) promedio)
    store = EventStore()
    store.add_many(eventos)
    print(f"Almacenados {len(store)} eventos.")
    print("Lookup por id (E0007):", store.get("E0007").resumen())

    # 2) Índice secundario por categoría
    idx = store.crear_indice("por_categoria", "categoria")
    print("\nEventos de categoría 'red':")
    for e in idx.get("red"):
        print(" -", e.resumen())

    # 3) Cola FIFO simple (bandeja de entrada)
    bandeja: Queue[Event] = Queue()
    for e in eventos:
        bandeja.enqueue(e)
    print(f"\nBandeja FIFO — primero en llegar: {bandeja.peek().id}")

    # 4) Cola de prioridad para atención
    pq = PriorityQueue()
    for e in eventos:
        pq.push(e)
    print("\nAtención por prioridad (top 5):")
    for _ in range(5):
        print(" -", pq.pop().resumen())

    # 5) Búsqueda de texto
    ta = TextAnalyzer(eventos)
    hits = ta.buscar("corte")
    print(f"\nEventos que mencionan 'corte': {len(hits)}")
    print("Conteo por palabra:", ta.contar_por_palabra(["corte", "alerta", "nodo"]))

    # 6) Router (grafo mínimo)
    r = Router()
    r.registrar_muchos(eventos)
    print("\nNodos en la red:", r.nodos())
    print("Vecinos de A:", r.vecinos("A"))


if __name__ == "__main__":
    main()
