"""Almacén de eventos con acceso O(1) por id y secuencia ordenada.

`EventStore` cumple dos roles:

1. Guardar los eventos en el orden en que llegan (una lista) para poder
   recorrerlos secuencialmente.
2. Mantener un índice hash (dict) por id para lookup en O(1) promedio.

Se apoya en la clase `Index` para índices secundarios (por categoría, por
origen, etc.), ver `index.py`.
"""

from __future__ import annotations

from typing import Iterable, Iterator, Optional

from .event import Event
from .index import Index


class EventStore:
    """Repositorio en memoria de eventos.

    Complejidades:
        add: O(1) amortizado (append + dict set).
        get: O(1) promedio (lookup en dict).
        __iter__: O(n) — recorre en orden de inserción.
    """

    def __init__(self) -> None:
        self._eventos: list[Event] = []
        self._por_id: dict[str, Event] = {}
        # Índices secundarios opcionales; se crean bajo demanda.
        self._indices: dict[str, Index] = {}

    # --- operaciones básicas -------------------------------------------------

    def add(self, evento: Event) -> None:
        """Agrega un evento. Lanza ValueError si el id ya existe."""
        if evento.id in self._por_id:
            raise ValueError(f"id duplicado: {evento.id}")
        self._eventos.append(evento)
        self._por_id[evento.id] = evento
        # Refrescar índices secundarios si los hay.
        for idx in self._indices.values():
            idx.add(evento)

    def add_many(self, eventos: Iterable[Event]) -> None:
        """Agrega múltiples eventos."""
        for e in eventos:
            self.add(e)

    def get(self, id_: str) -> Optional[Event]:
        """Devuelve el evento con ese id, o None si no existe. O(1) promedio."""
        return self._por_id.get(id_)

    def __len__(self) -> int:
        return len(self._eventos)

    def __iter__(self) -> Iterator[Event]:
        return iter(self._eventos)

    def as_list(self) -> list[Event]:
        """Copia superficial de los eventos, útil para pasar a algoritmos."""
        return list(self._eventos)

    # --- índices secundarios -------------------------------------------------

    def crear_indice(self, nombre: str, atributo: str) -> Index:
        """Crea un índice hash por el atributo indicado (p. ej. 'categoria').

        Un índice puede tener varios eventos por clave (multi-valor), por eso
        `Index` guarda listas.
        """
        idx = Index(atributo)
        for e in self._eventos:
            idx.add(e)
        self._indices[nombre] = idx
        return idx

    def indice(self, nombre: str) -> Index:
        return self._indices[nombre]
