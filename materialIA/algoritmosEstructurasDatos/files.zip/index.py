"""Índice hash multi-valor sobre un atributo de Event.

Se implementa sobre `dict` de Python (que a su vez es una tabla hash con
direccionamiento abierto y sondeo). Se elige `dict` porque:

- Amortiza inserción y búsqueda a O(1) promedio.
- Resuelve colisiones internamente (no es responsabilidad del usuario).
- Está altamente optimizado en CPython (implementado en C).

Sobre colisiones (conceptual): dos claves distintas pueden producir el
mismo hash. Las estrategias clásicas son encadenamiento (listas por bucket)
y direccionamiento abierto (buscar el próximo slot libre). CPython usa
direccionamiento abierto con sondeo perturbado, lo que da muy buena
localidad de memoria y evita punteros extra. El costo esperado se mantiene
en O(1) siempre que el factor de carga sea razonable (< 2/3), condición
que `dict` mantiene redimensionando automáticamente.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Iterator

from .event import Event


class Index:
    """Índice hash multi-valor.

    Cada clave (valor del atributo indexado) mapea a una lista de eventos.
    Ejemplo: si el atributo es 'categoria', la clave 'red' podría contener
    varios incidentes de categoría 'red'.
    """

    def __init__(self, atributo: str) -> None:
        self.atributo = atributo
        self._tabla: dict[object, list[Event]] = defaultdict(list)

    def add(self, evento: Event) -> None:
        clave = getattr(evento, self.atributo)
        self._tabla[clave].append(evento)

    def get(self, clave: object) -> list[Event]:
        """Devuelve la lista de eventos para esa clave (vacía si no hay)."""
        return list(self._tabla.get(clave, []))

    def keys(self) -> Iterator[object]:
        return iter(self._tabla.keys())

    def __len__(self) -> int:
        return sum(len(v) for v in self._tabla.values())

    def __contains__(self, clave: object) -> bool:
        return clave in self._tabla
