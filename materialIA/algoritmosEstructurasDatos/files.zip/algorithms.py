"""Algoritmos de búsqueda y ordenamiento (didácticos).

Cumple el punto 3 del entregable. Se implementan:

Búsqueda:
    - `busqueda_secuencial`: O(n).
    - `busqueda_binaria`:    O(log n), requiere lista ordenada. Se usa
      `bisect` como envoltorio idiomático de Python.

Ordenamiento (los dos más didácticos a nuestro criterio):
    - `insertion_sort`: O(n²) peor caso, O(n) mejor caso.
      Es simple, estable y muy rápido en listas casi ordenadas.
    - `mergesort`:      O(n log n) siempre, estable, no in-place.
      Ilustra el paradigma divide y vencerás.

Ambos aceptan un `key` para ordenar por atributo del Event.
"""

from __future__ import annotations

from bisect import bisect_left
from typing import Callable, Optional, Sequence, TypeVar

T = TypeVar("T")


# --------------------------------------------------------------------------
# BÚSQUEDA
# --------------------------------------------------------------------------

def busqueda_secuencial(seq: Sequence[T], objetivo: T) -> int:
    """Recorre la secuencia; devuelve el índice o -1. O(n)."""
    for i, x in enumerate(seq):
        if x == objetivo:
            return i
    return -1


def busqueda_binaria(seq: Sequence[T], objetivo: T) -> int:
    """Busca en secuencia ordenada. O(log n). Devuelve índice o -1."""
    i = bisect_left(seq, objetivo)
    if i != len(seq) and seq[i] == objetivo:
        return i
    return -1


# --------------------------------------------------------------------------
# ORDENAMIENTO
# --------------------------------------------------------------------------

def insertion_sort(
    seq: list[T], key: Optional[Callable[[T], object]] = None
) -> list[T]:
    """Ordenamiento por inserción, in-place. Devuelve la misma lista.

    Complejidad temporal:
        - Mejor caso  (ya ordenada):  O(n).
        - Peor caso   (inversa):      O(n²).
        - Promedio:                   O(n²).
    Complejidad espacial: O(1).
    Estable: sí.
    """
    k = key or (lambda x: x)
    for i in range(1, len(seq)):
        actual = seq[i]
        clave = k(actual)
        j = i - 1
        while j >= 0 and k(seq[j]) > clave:
            seq[j + 1] = seq[j]
            j -= 1
        seq[j + 1] = actual
    return seq


def mergesort(
    seq: list[T], key: Optional[Callable[[T], object]] = None
) -> list[T]:
    """Ordenamiento por mezcla. Devuelve una lista nueva ordenada.

    Complejidad temporal: O(n log n) en todos los casos.
    Complejidad espacial: O(n) (no es in-place).
    Estable: sí.
    """
    k = key or (lambda x: x)

    def _merge(a: list[T], b: list[T]) -> list[T]:
        out: list[T] = []
        i = j = 0
        while i < len(a) and j < len(b):
            if k(a[i]) <= k(b[j]):
                out.append(a[i]); i += 1
            else:
                out.append(b[j]); j += 1
        out.extend(a[i:])
        out.extend(b[j:])
        return out

    if len(seq) <= 1:
        return list(seq)
    mid = len(seq) // 2
    izq = mergesort(seq[:mid], key)
    der = mergesort(seq[mid:], key)
    return _merge(izq, der)
