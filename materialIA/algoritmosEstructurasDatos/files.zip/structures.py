"""TDA lineales: Queue (FIFO) y PriorityQueue.

Cumple el punto 2 del entregable. Ambas estructuras encapsulan las
primitivas de la biblioteca estándar y ofrecen una interfaz simple y
tipada.

Queue: cola FIFO sobre `collections.deque`.
    - enqueue: O(1)
    - dequeue: O(1)
    - peek:    O(1)

PriorityQueue: cola de prioridad sobre `heapq` (min-heap binario).
    - push:  O(log n)
    - pop:   O(log n) — devuelve el elemento de mayor prioridad
             (menor valor de `prioridad`).
    - peek:  O(1)
    Como `heapq` no es estable, se agrega un contador incremental como
    segunda clave para desempatar por orden de inserción y evitar que
    Python intente comparar los objetos `Event` cuando la prioridad
    empata (aunque `Event` ya define orden, es una defensa útil).
"""

from __future__ import annotations

import heapq
import itertools
from collections import deque
from typing import Generic, Optional, TypeVar

from .event import Event

T = TypeVar("T")


class Queue(Generic[T]):
    """Cola FIFO."""

    def __init__(self) -> None:
        self._d: deque[T] = deque()

    def enqueue(self, x: T) -> None:
        self._d.append(x)

    def dequeue(self) -> T:
        if not self._d:
            raise IndexError("dequeue de cola vacía")
        return self._d.popleft()

    def peek(self) -> T:
        if not self._d:
            raise IndexError("peek de cola vacía")
        return self._d[0]

    def __len__(self) -> int:
        return len(self._d)

    def __bool__(self) -> bool:
        return bool(self._d)


class PriorityQueue:
    """Cola de prioridad de eventos.

    Menor `prioridad` = mayor urgencia (convención de min-heap).
    Desempate por timestamp y por orden de inserción.
    """

    def __init__(self) -> None:
        self._h: list[tuple[int, float, int, Event]] = []
        self._contador = itertools.count()

    def push(self, evento: Event) -> None:
        # (prioridad, timestamp numérico, tiebreaker, evento)
        ts = evento.timestamp.timestamp()
        heapq.heappush(
            self._h,
            (evento.prioridad, ts, next(self._contador), evento),
        )

    def pop(self) -> Event:
        if not self._h:
            raise IndexError("pop de cola vacía")
        return heapq.heappop(self._h)[3]

    def peek(self) -> Event:
        if not self._h:
            raise IndexError("peek de cola vacía")
        return self._h[0][3]

    def __len__(self) -> int:
        return len(self._h)

    def __bool__(self) -> bool:
        return bool(self._h)
